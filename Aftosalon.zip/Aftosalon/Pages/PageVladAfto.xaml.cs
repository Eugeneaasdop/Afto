﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageVladAfto.xaml
    /// </summary>
    public partial class PageVladAfto : Page
    {
        private VladAfto _currentVladAfto = new VladAfto();
        public PageVladAfto()
        {
            InitializeComponent();
            CMBafto.ItemsSource = AfroserviceEntities.GetContext().Afto.ToList();
            CMBvlad.ItemsSource = AfroserviceEntities.GetContext().Vlad.ToList();
            CMBafto.SelectedValuePath = "Id_spisokafto";
            CMBafto.DisplayMemberPath = "Gosnomer";
            CMBvlad.SelectedValuePath = "Id_vlad";
            CMBvlad.DisplayMemberPath = "Surname";
            DataContext = _currentVladAfto;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new GlavMenu());
        }

        private void Addvlad_Click(object sender, RoutedEventArgs e)
        {
            if (_currentVladAfto.Id_Vladafto == 0)
                AfroserviceEntities.GetContext().VladAfto.Add(_currentVladAfto);
            try
            {
                AfroserviceEntities.GetContext().SaveChanges();
                MessageBox.Show("Данные сохранены");
                ClassFrame.frmObj.Navigate(new PageVladAfto());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
