﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageVladAdd.xaml
    /// </summary>
    public partial class PageVladAdd : Page
    {
        private Vlad _currentVlad = new Vlad();
        public PageVladAdd(Vlad selectedvlad)
        {
            InitializeComponent();
            if (selectedvlad != null)
            {
                _currentVlad = selectedvlad;
                Titletxt.Text = "Изменение владельца";
                btnAddAfto.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentVlad;
        }

        private void btnAddAfto_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentVlad.Surname)) error.AppendLine("Укажите имя");
            if (string.IsNullOrWhiteSpace(_currentVlad.Name)) error.AppendLine("Укажите фамилию");
            if (string.IsNullOrWhiteSpace(_currentVlad.Patronymic)) error.AppendLine("Укажите отчество");
            if (string.IsNullOrWhiteSpace(_currentVlad.Telefon)) error.AppendLine("Укажите телефон");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentVlad.Skidka))) error.AppendLine("Укажите скидку");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentVlad.Id_vlad == 0)
            {
                AfroserviceEntities.GetContext().Vlad.Add(_currentVlad);
                try
                {
                    AfroserviceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageVlad());
                    MessageBox.Show("Новый владелец успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    AfroserviceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageVlad());
                    MessageBox.Show("Владелец успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVlad());
        }
    }
}
