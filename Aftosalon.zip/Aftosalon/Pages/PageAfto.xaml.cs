﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;
using System.IO;
using Newtonsoft.Json;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAfto.xaml
    /// </summary>
    public partial class PageAfto : Page
    {
        public PageAfto()
        {
            InitializeComponent();
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Afto.ToList();
            var listMark = AfroserviceEntities.GetContext().Afto.Select(x => x.Marka).Distinct().ToList();
            CMBFilterAfto.Items.Add("Все марки");
            foreach (string marka in listMark)
            {
                CMBFilterAfto.Items.Add(marka);
            }
        }

        private void BTNedit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAftoAdd((Afto)DtgSQL.SelectedItem));
        }
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageService());
        }

        private void CMBFilterAfto_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string marka = CMBFilterAfto.SelectedValue.ToString();
            if (marka != "Все марки")
                DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Afto.Where(x => x.Marka == marka).ToList();
            else
                DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Afto.ToList();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new GlavMenu());
        }

        private void FindAfto_TextChanged(object sender, TextChangedEventArgs e)
        {
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Afto.Where(x => x.Gosnomer.ToLower().Contains(FindAfto.Text.ToLower())).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Afto.OrderByDescending(x => x.Marka).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Afto.OrderBy(x => x.Marka).ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageVlad());
        }

        private void Delette_Click(object sender, RoutedEventArgs e)
        {
            var AftoForRemoving = DtgSQL.SelectedItems.Cast<Afto>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить следующие {AftoForRemoving.Count()} записи?", "Внимание",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    AfroserviceEntities.GetContext().Afto.RemoveRange(AftoForRemoving);
                    AfroserviceEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");
                    DtgSQL.ItemsSource = AfroserviceEntities.GetContext().Afto.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Btnadd_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAftoAdd(null));
        }
    }
}
