﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Aftosalon.Classes;

namespace Aftosalon.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAftoAdd.xaml
    /// </summary>
    public partial class PageAftoAdd : Page
    {
        private Afto _currentAfto = new Afto();
        public PageAftoAdd(Afto selectedAto)
        {
            InitializeComponent();
            if (selectedAto != null)
            {
                _currentAfto = selectedAto;
                Titletxt.Text = "Изменение автомобиля";
                btnAddAfto.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentAfto;
        }

        private void btnAddAfto_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentAfto.Gosnomer)) error.AppendLine("Укажите госномер");
            if (string.IsNullOrWhiteSpace(_currentAfto.Marka)) error.AppendLine("Укажите марку");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentAfto.Id_spisokafto == 0)
            {
                AfroserviceEntities.GetContext().Afto.Add(_currentAfto);
                try
                {
                    AfroserviceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageAfto());
                    MessageBox.Show("Новый автомобиль успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    AfroserviceEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageAfto());
                    MessageBox.Show("автомобиль успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageAfto());
        }
    }
}
